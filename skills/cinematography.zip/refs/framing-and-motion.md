# Framing and Camera Motion
## 1.Visual Motion Envelope
根据当前 Shot 的开始位置、主要运动路径、关键状态变化、结束位置和必须保持可见的空间锚点，估计主体在整个 Shot 中需要占据的可见画面范围。
## 2.景别与构图
景别和构图应一次性覆盖主要 Visual Motion Envelope，并真实保留距离阶段、运动方向和事件结果。构图容量不足时依次考虑更宽景别、更远观察距离、调整静态覆盖范围或重新选择机位。
## 3.运镜决策
运镜只在能增加事件可读性、跟随叙事重点或自然保持关键动作可见时使用。稳定机位已经能完整表达事件时优先 stable / near-static observation。摄影机运动不能代替人物真实移动，也不用于单纯维持人物居中。
## 4.运镜语义
明确区分摄影机位置变化与镜头朝向变化。tracking/dolly/truck 表示摄影机位置运动；pan/tilt 表示观察方向旋转；zoom 表示焦距变化。最终描述应让摄影机运动与主体运动分别清楚。
## 5.尾部收势
非 STATIC 运镜形成自然速度包络：启动或承接 → 稳定运动 → Shot 尾部平滑减速 → stable / near-stable ending view。摄影机收势不要求人物同时停止。
