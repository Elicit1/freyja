# Spatial Projection
本文件负责把 Worker 的 World Space 转换为当前摄影机下的 Screen Space。
## 1.World Space保持不变
世界事实包括人物所在区域、真实前后左右、身体朝向、移动方向、路径、距离关系、道具位置和事件结果。摄影机只能观察这些事实。
## 2.Screen Space推导
机位确定后，根据几何关系推导：screen left/right、foreground/background、depth、apparent scale、screen direction、occlusion、projected overlap、screen order 和人物相对摄影机朝向。
## 3.多主体关系
分别计算每个主体的屏幕运动，再描述主体之间的视觉距离变化与顺序变化。高层关系词应由这些二维结果支撑，而不是反过来用高层关系词替代空间描述。
## 4.遮挡与投影重叠
短暂遮挡或轮廓重叠只代表二维投影结果，不自动代表三维接触、融合、穿模或人物互动。遮挡结束后恢复显示的仍是同一物理主体。
## 5.Screen-order exchange
当真实轨迹和机位共同造成画面顺序变化时，明确描述顺序变化及其后的持续运动。顺序交换是同一主体沿连续轨迹移动的结果，不是角色重新生成或随机换位。
## 6.结果校验
如果二维表达需要修改世界事实才能成立，说明当前机位或构图错误，应重新选择摄影方案，而不是改写 Worker 状态。
