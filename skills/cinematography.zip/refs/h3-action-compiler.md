# H3 Action Compiler
本文件用于把剧情自然语言转换为 H3 更容易稳定执行的动作语言。核心目标是保持剧情语义不变，同时减少高层动词、关系词和状态词触发额外动作。
## 1.先识别动作类型
- 持续状态：物体或身体已经处于某状态，例如持有、佩戴、注视、站立、坐着。
- 状态变化：从 A 明确变为 B，例如拿起、放下、打开、关闭、递交、转身。
- 连续主体运动：走、跑、起身、坐下、伸手等可直接观察的身体运动。
- 关系性空间事件：接近、经过、相遇、交汇、跟随、追赶、超越、避让、离开等，它们本质上由多个主体轨迹和距离变化组成。
- 被动次级运动：头发、衣物、袋子、挂件受步伐、惯性、风或重力影响产生的从属运动。
## 2.状态优先语法
H3 描述优先采用：当前状态 → 主体连续运动 → 可观察空间/身体变化 → 结果状态。不要让一个高层动词同时承担路径、接触、表情、速度和结果等多种含义。
例如“右手提着袋子走”优先表达为“袋子已经保持在右手自然下垂位置，人物持续行走，袋子只随步伐轻微摆动”，而不是把 carry/hold/lift 混写成主动抬举。
## 3.持续状态转换
持续持有、佩戴、注视和姿态应写成保持状态。只有剧情明确要求状态发生变化时，才使用 raise、lift、pick up、put down、hand over、open、close、turn 等主动变化词。已经持有的物体应保持既定手、位置和姿态，并只产生必要被动运动。
## 4.关系词转换为物理过程
关系性动作优先改写为各主体独立轨迹和相对状态变化：
- 接近：分别描述双方轨迹，并明确距离持续缩短。
- 离开/远离：主体沿既定方向继续运动，与目标或另一主体的距离持续增大。
- 跟随：后方主体沿前方主体已确定的路线继续运动，并保持剧情规定的前后顺序和距离趋势。
- 追赶：后方主体保持同一路径关系，双方前后顺序不变，同时间距按剧情持续缩短。
- 超越：后方 → 接近 → 并列或局部重叠阶段 → 前后顺序交换 → 超越者位于前方。
- 相遇/交汇/经过：分别描述各自路径 → 距离变化 → 到达共同空间区域 → 必要的二维投影关系变化 → 各自结果状态。
- 避让：只有剧情明确要求改变路径或身体姿态时，才描述具体让行轨迹和身体变化。
词语本身不是必须保留的。只要物理过程与剧情事实等价，可以完全不用原动作词。
## 5.关系动作归一化
当剧情事实可以由独立轨迹、距离变化和结果位置完整表达时，优先使用空间状态语言而不是高歧义关系词。
- 尚未交汇：distance decreases → remaining gap becomes small → trajectories have not crossed yet。
- 完成交汇：distance decreases → trajectories cross once → relative/screen order changes when applicable → separation increases。
- 完成超越：gap closes → temporary overlap or side-by-side phase → order changes → overtaking subject continues ahead。
只有身体接触本身属于剧情事实时，才使用描述接触的动作语言。
## 6.敏感动作词处理
当一个词容易诱发模型增加接触、冲击、夸张身体反应、抬举、展示、停顿或互动时，不直接依赖该词，而拆成低歧义动作组件。常见处理原则：
- brush past / shoulder-to-shoulder / squeeze past：若剧情只要求经过，改写为两条独立连续轨迹、距离缩短、必要的投影交错/遮挡、顺序变化和继续分离；只有明确接触时才描述接触。
- meet / encounter：改写为主体到达同一空间关系以及剧情实际发生的后续行为，避免自动推导停步、对视或交流。
- approach：补充谁沿什么方向运动、谁保持原地或同时运动，以及距离如何变化。
- leave：补充主体离开什么区域、沿什么方向继续，以及与空间锚点的距离如何变化。
- carry / hold：若只是持续状态，优先描述物体保持在哪只手、身体哪个位置，而不是强调主动 hold up / raise。
- turn：明确是身体转向、头部转向还是视线改变，并描述起始朝向与结果朝向。
- look：明确头部、眼睛和目标关系；持续注视优先写成 gaze remains on target，而不是重复 look at 动作。
- fall / drop：区分主动放手、物体脱落与重力下落，写清触发方式和后续运动。
## 7.Locomotion Physical Consistency
对于主要人物的 walking、running、jogging、approaching、leaving、following 等持续位移动作，默认执行 locomotion consistency 编译。每个移动主体都必须分别建立：travel direction → body orientation → alternating steps → weight transfer → spatial displacement。人物的空间位移应由连续步态产生，而不是只表现为身体整体平移。
- 身体主要朝向与 travel direction 一致。
- 躯干、髋部、腿部和脚部共同服务于同一前进方向。
- 使用自然交替步伐与重心转移建立脚步和身体位移之间的因果。
- 可使用 `alternating forward steps`、`normal weight transfer`、`steps propel the body forward along the path` 等低歧义语义。
- 头发、衣物和手持道具的摆动属于步态产生的从属运动，不能替代主体 locomotion。
推荐把抽象的“walk toward X”编译为类似：`walks naturally toward the destination, facing the same direction as travel, with alternating forward steps and normal weight transfer propelling the body along the path.` 保持自然整体动作，不展开成逐帧腿部关节控制。
## 8.Multi-Subject Locomotion Compilation
当 Shot 中有多个主要人物同时执行持续位移时，分别对每个移动主体完成 locomotion consistency 编译，而不是只处理视觉重点人物。每个人物独立保持自己的 travel direction、body orientation、step cycle、weight transfer 和 spatial progression。不同主体的方向和速度根据其真实轨迹分别表达，不复制另一主体的方向语言，也不因摄影机关注其中一人而弱化其他主要移动主体的步态物理关系。
## 9.Motion Verb Compilation
持续空间位移动作优先按以下语义顺序编译：travel direction → body orientation → locomotion mechanism → spatial progression → resulting position。screen-space 方向只有在摄影方案已确定且与真实轨迹一致时才加入。对于 walk/run/approach/leave 等词，不只保留抽象动词，还应补充能够说明人物如何真实推进的物理语义。
## 10.动作阶段只在必要时展开
简单动作保持自然整体；复杂动作才拆成准备 → 执行 → 结果。拆分的目的是减少歧义，不是生成逐帧机械指令。多个自然同时发生的从属动作可以并行表达。
## 11.单次事件与结果状态
具有明确结果的动作完成后，后续语言从结果状态继续。例如完成交汇后直接描述双方继续各自路线并逐渐分离；完成递交后直接描述新持有人继续持有。不要重复使用会把模型拉回动作起点的同一强动作词。
## 12.实例连续性语言
高风险镜头可在动作段开头加入一句简短正向约束：`Each named character remains one continuous physical instance throughout the shot; all movement, rotation, occlusion and screen-order changes apply to the same persistent body.` 只在交汇、明显遮挡、重新显露、较大位置交换或复制风险明显时使用，不机械重复。
