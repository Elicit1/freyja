---
name: cinematography
description: "MiniMax H3视觉导演Skill。基于Worker提供的剧情与三维世界状态，自主选择可读机位，将剧情事件与动作编译为低歧义、可执行的H3视觉语言，并完成二维空间、构图、运镜与连续性控制。"
---
## 1.定位
本 Skill 负责把 Worker 已确定的剧情事实和三维世界状态转换为 H3 可执行的视觉方案。输入包括人物、动作目标、真实位置、身体朝向、移动方向、距离变化、道具状态、事件顺序和结果；本 Skill 负责选择摄影机观察关系，并将这些事实转换为 screen-space、景别、构图、必要运镜和 H3 动作执行语言。视觉设计只改变观察与表达方式，不改变剧情事实。
## 2.执行顺序
按以下顺序工作：读取 World Facts → 提取不可改变的 Event Invariants → 识别动作类型 → 将剧情动作编译为低歧义物理过程 → 选择可读机位 → 推导二维投影 → 验证运动与空间关系 → 选择景别与构图 → 决定是否运镜 → 输出 H3 可执行视觉语言。事件可读性优先于摄影复杂度。
## 3.H3动作编译
剧情自然语言动作词只表示语义，不默认直接写入 H3。先判断动作属于持续状态、状态变化、连续主体运动、关系性空间事件或被动次级运动，再改写为“当前状态 → 连续运动 → 可观察变化 → 结果状态”。持续持有、佩戴、注视等状态保持为状态；只有剧情明确发生变化时才使用 raise、lift、pick up、put down、hand over、open、close、turn 等主动变化词。已经持有的道具保持既定手部、位置和姿态，并只产生必要被动运动。
## 4.关系动作归一化
approach、meet、pass、cross、brush past、leave、follow、chase、overtake 等关系词优先转换为各主体独立轨迹、距离变化和结果状态，而不是依赖高层关系词本身。接近表达为各自沿既定轨迹运动且距离持续缩短；尚未交汇时表达为 remaining gap becomes small 且 trajectories have not crossed yet；完成交汇时表达为 distance decreases → trajectories cross once → relative/screen order changes when applicable → separation increases；超越表达为 gap closes → temporary overlap/side-by-side phase → order changes → overtaking subject continues ahead。只有身体接触本身属于剧情事实时才描述接触。关系词可能诱发停顿、对视、碰撞、回头、避让或额外互动时，应改写为等价的轨迹与状态变化。只要轨迹、距离和结果状态已经足以表达剧情，最终 H3 正文中就不再重新引入 brush past、shoulder-to-shoulder、almost brushing、about to brush past 等关系性词组；优先直接写 remaining gap、trajectories have/have not crossed、relative order、separation 等可观察状态。
## 5.Locomotion物理一致性
所有主要人物的 walking、running、jogging、approaching、leaving、following 等持续位移都必须分别执行 locomotion consistency 编译。每个移动主体建立 travel direction → body orientation → alternating steps → weight transfer → spatial displacement 的一致关系。身体主要朝向与真实行进方向一致，躯干、髋部、腿部和脚部共同服务于该方向；人物位移由连续步态和正常重心转移产生，而不是主体整体平移。优先使用类似 `alternating forward steps`、`normal weight transfer`、`steps propel the body forward along the path` 的物理语义。持续位移不使用 slide、glide、drift 等词描述人物本体的步行推进；这些词仅用于确实发生滑行、漂浮或摄影机/环境运动的情况。多人同时移动时，对每个主要移动主体分别完成该编译，不因视觉焦点集中于其中一人而弱化其他主体的步态物理关系。该规则必须落实到最终 H3 动作描述中：每个持续 locomotion 的主要主体都应实际获得完整的方向、步态与位移语义，而不是只在内部分析中成立。不同主体可以使用不同措辞，但语义完整度应一致；不能只为主关注人物写 alternating steps / weight transfer / body propulsion，而把其他移动主体简化为单独的 walks left/right。
## 6.被动物理运动
头发、衣物、手臂、购物袋、挂件等由步态、惯性、风或重力产生的运动属于主要动作的从属效果。主要 locomotion 持续时，这些被动运动应与当前步态自然同步并持续存在；只有主要动作停止、外力变化或剧情明确改变状态时才随之减弱、停止或改变。被动运动不能替代主体真实 locomotion，也不单独形成新的剧情事件。
## 7.机位选择
机位选择先读取主体真实位置、身体朝向、运动轴、真实移动方向、距离趋势、关键空间锚点、交互区域和结果状态，再提取无论机位如何都必须保留的 Event Invariants，例如距离缩短或增大、路径交叉、前后顺序变化、追赶/超越、目标方向、交接关系或事件结果。优先选择能同时看清主要运动轴、距离变化和结果状态的观察方向。人物相对摄影机的 front / three-quarter / profile / back 来自真实身体朝向与摄影机位置的几何关系，参考图正脸不覆盖当前身体朝向。
## 8.World/Camera/Screen参考系一致性
移动摄影机时始终区分 subject world-space motion、camera world-space motion 和 subject screen-space motion。三者必须形成自洽关系：摄影机与人物同方向且速度接近时，人物通常在画面中相对稳定，由背景反向运动体现前进；若人物需要持续明显横穿画面，摄影机方向和速度必须允许该 screen-space 位移成立。screen-space 位移不能替代真实 locomotion，摄影机移动也不能替代人物真实前进。若某方案同时要求互相矛盾的 world-space 与 screen-space 运动，应重新选择机位或降低摄影机运动复杂度。
## 9.运动复杂度预算
当 Shot 的主要叙事依赖 walking、running、追逐、交汇、超越或多人连续位移时，优先保持摄影参考系清晰稳定。主体运动越复杂，摄影机越应减少不必要的 tracking、truck、arc 或组合运镜。只有摄影机运动明显提高事件可读性且不会增加方向、步态或相对运动歧义时才使用。稳定观察不是默认风格，而是复杂 locomotion 下减少运动求解负担的优先策略。
## 10.三维到二维投影
摄影机确定后，根据真实三维关系推导 screen left/right、foreground/background、depth、apparent scale、screen direction、occlusion、projected overlap、screen order 和人物相对摄影机朝向。多主体分别计算屏幕运动，再描述视觉距离与顺序变化。短暂遮挡或轮廓重叠只代表二维投影结果，不自动代表三维接触、融合或互动。screen-order exchange 必须来自同一主体沿连续真实轨迹移动的投影结果。若二维表达必须修改 Worker 世界事实才能成立，应重新选择摄影方案。
## 11.构图与运镜
根据 Shot 的起始位置、主要路径、关键状态变化、结束位置和空间锚点确定 Visual Motion Envelope。景别和构图应覆盖主要运动范围并保留关键距离关系和事件结果。运镜只在提高事件可读性、保持关键动作可见或服务叙事重点时使用；稳定机位已经足够时优先 stable / near-static observation。明确区分 tracking/dolly/truck 的摄影机位置变化、pan/tilt 的观察方向变化和 zoom 的焦距变化。非 STATIC 运镜在 Shot 尾部自然减速并收束至 stable / near-stable ending view，摄影机收势不要求人物停止。
## 12.时间与状态连续性
当前 Shot 从最新世界状态开始。人物所在区域、身体朝向、移动方向、距离关系、动作阶段、表情视线、道具数量、归属和持有方式持续继承，只有剧情动作明确改变的状态才更新。已完成事件的结果直接成为后续状态；进入、离开、交汇、超越、拿取、放下、开关、交接等事件完成后，从完成状态继续推进，不重新回到动作起点。
## 13.人物实例连续性
每个命名角色在同一 Shot 中保持一个连续物理实例。移动、转身、遮挡、重新显露、前后景变化、screen-order exchange、景别变化和不同可见朝向都作用于同一个 persistent body。交汇、明显遮挡、重新显露或大幅位置交换等高风险镜头，可加入一句简短正向约束：`Each named character remains one continuous physical instance throughout the shot; all movement, rotation, occlusion and screen-order changes apply to the same persistent body.`
## 14.道具连续性
道具保持数量、归属、持有部位、位置和当前状态。画面裁切或遮挡不会使画外道具消失，也不会生成替代实例。持续持有属于状态；拿起、放下、递交、打开、关闭、掉落等才属于状态变化。道具随人物步态产生的自然摆动只作为从属运动，不改变数量、归属或持有方式。
## 15.动作表达粒度
简单动作保持自然整体；复杂动作才拆成准备 → 执行 → 结果。拆分用于减少歧义，不生成逐帧机械关节控制。多个自然同时发生的从属动作可以并行表达。具有明确结果的动作完成后，后续语言从结果状态继续，避免重复使用强动作词把模型拉回动作起点。
## 16.可选扩展refs
主 SKILL.md 已包含所有必须生效的核心规则；不读取 refs 也应能完成正确执行。仅在需要更细的高级导演推导时可按需读取：`refs/camera-selection.md`、`refs/h3-action-compiler.md`、`refs/spatial-projection.md`、`refs/framing-and-motion.md`、`refs/continuity.md`。refs 只用于补充细节，不承担关键正确性规则。
## 17.最终校验
输出前确认：剧情事实未改变；高层动作已转换为可观察物理过程；所有主要移动主体均在最终 H3 动作描述中实际具有 travel direction、body orientation、alternating steps、weight transfer 与 spatial displacement 的一致关系，且多主体之间的 locomotion 语义完整度一致；人物步行位移没有被 slide/glide/drift 式整体平移替代；关系性动作已优先转换为独立轨迹、距离变化和结果状态，且当这些状态已经足够时最终正文未重新引入 brush past、shoulder-to-shoulder、almost brushing 等敏感关系词；机位能够直接呈现核心事件；subject world-space motion、camera world-space motion 与 subject screen-space motion 自洽；复杂主体运动下没有无收益增加摄影机复杂度；二维投影与真实三维状态一致；景别覆盖主要运动范围；人物和道具状态连续；被动物理运动与主要动作同步；每个命名角色保持单一连续实例；已完成事件结果正确继承；最终描述以具体状态、轨迹和运动结果为主。
